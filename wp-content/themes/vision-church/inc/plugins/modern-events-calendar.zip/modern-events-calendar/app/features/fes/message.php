<?php
/** no direct access **/
defined('_MECEXEC_') or die();
?>
<div class="mec-fes-message">
    <p><?php echo $message; ?></p>
</div>
<?php
// Way to set menu, import revolution slider, set blog page and set home page
if ( !function_exists( 'vision_wbc_extended' ) ) :

	add_action( 'wbc_importer_after_content_import', 'vision_wbc_extended', 10, 2 );

	function vision_wbc_extended( $demo_active_import , $demo_directory_path ) {

		reset( $demo_active_import );
		$current_key = key( $demo_active_import );

		if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) ) :

			/**
			 * Import theme options
			 *
			 * @since 1.0.0
			 */
			// Get file contents and decode
			$file = $demo_directory_path . 'theme_options.txt';
			$data = file_get_contents( $file );
			$data = json_decode( $data, true );
			$data = maybe_unserialize( $data );
			update_option( 'vision_church_options', $data );

			/**
			 * Add menus - the menus listed here largely depend on the ones registered in the theme
			 *
			 * @since 1.0.0
			 */
			$topbar_menu		= get_term_by( 'name', 'Topbar Menu', 'nav_menu' );
			$header_menu		= get_term_by( 'name', 'Header Menu', 'nav_menu' );
			$one_page_menu		= get_term_by( 'name', 'Onepage Header Menu', 'nav_menu' );
			$duplex_left_menu	= get_term_by( 'name', 'Duplex Menu - Left', 'nav_menu' );
			$duplex_right_menu	= get_term_by( 'name', 'Duplex Menu - Right', 'nav_menu' );
			$footer_menu		= get_term_by( 'name', 'Footer Menu', 'nav_menu' );
			$locations	 		= array();

			if ( $topbar_menu )
				$locations['header-top-menu'] = $topbar_menu->term_id;

			if ( $header_menu )
				$locations['header-menu'] = $header_menu->term_id;

			if ( $one_page_menu )
				$locations['onepage-header-menu'] = $one_page_menu->term_id;

			if ( $duplex_left_menu )
				$locations['duplex-menu-left'] = $duplex_left_menu->term_id;

			if ( $duplex_right_menu )
				$locations['duplex-menu-right'] = $duplex_right_menu->term_id;

			if ( $footer_menu )
				$locations['footer-menu'] = $footer_menu->term_id;

			if ( $locations )
				set_theme_mod( 'nav_menu_locations', $locations );


			/**
			 * Set HomePage
			 *
			 * @since 1.0.0
			 */
			$wbc_home_pages = array(
				'Discovery'		=> 'Home 1',
                'Forward'       => 'Home 1',
			);

			if ( array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_home_pages ) ) :
				$home_page = get_page_by_title( $wbc_home_pages[$demo_active_import[$current_key]['directory']] );
				if ( isset( $home_page->ID ) ) :
					update_option( 'page_on_front', $home_page->ID );
					update_option( 'show_on_front', 'page' );
				endif;
			endif;


			/**
			 * Set BlogPage
			 *
			 * @since 1.0.0
			 */
			$wbc_blog_pages = array(
				'Discovery'		=> 'Blog',
                'Forward'       => 'Blog',
			);

			if ( array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_blog_pages ) ) :
				$blog_page = get_page_by_title( $wbc_blog_pages[$demo_active_import[$current_key]['directory']] );
				if ( isset( $blog_page->ID ) ) :
					update_option( 'page_for_posts', $blog_page->ID );
				endif;
			endif;


			/**
			 * Import slider(s) for the current demo being imported
			 *
			 * @since 1.0.0
			 */
			if ( class_exists( 'RevSlider' ) && get_option( 'vision_revslider_imported' ) != 'done' ) :
				// Set sliders zip name
				$wbc_sliders_array = array(
                    'Discovery'     => array( 'discovery-slider1.zip', 'discovery-slider2.zip' ),
					'Forward'		=> array( 'forward-slider1.zip' ),
				);

				if ( array_key_exists( $demo_active_import[$current_key]['directory'], $wbc_sliders_array ) ) :
					$wbc_slider_imports = $wbc_sliders_array[$demo_active_import[$current_key]['directory']];
					if ( is_array( $wbc_slider_imports ) ) :
						foreach( $wbc_slider_imports as $wbc_slider_import ) :
							if ( file_exists( $demo_directory_path.$wbc_slider_import ) ) :
								$slider = new RevSlider();
								$slider->importSliderFromPost( true, true, $demo_directory_path.$wbc_slider_import );
							endif;
						endforeach;
					endif;
				endif;

				add_option( 'vision_revslider_imported', 'done' );
			endif; // end Import slider(s)

			/**
			 * Import mec table.
			 *
			 * @since 1.0.0
			 */
			// wordpress global db
			global $wpdb;
			// define table name
			$table_name = $wpdb->prefix . 'mec_events';
			// check if mec is not installed
			if( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) != $table_name ) :
				//table not in database. Create new table
				$charset_collate = $wpdb->get_charset_collate();

				$sql = "CREATE TABLE $table_name (
				`id` int(10) NOT NULL,
				`post_id` int(10) NOT NULL,
				`start` date NOT NULL,
				`end` date NOT NULL,
				`repeat` tinyint(4) NOT NULL DEFAULT '0',
				`rinterval` varchar(255) DEFAULT NULL,
				`year` varchar(255) DEFAULT NULL,
				`month` varchar(255) DEFAULT NULL,
				`day` varchar(255) DEFAULT NULL,
				`week` varchar(255) DEFAULT NULL,
				`weekday` varchar(255) DEFAULT NULL,
				`weekdays` varchar(255) DEFAULT NULL,
				`days` text NOT NULL,
				`not_in_days` text NOT NULL,
				`time_start` int(10) NOT NULL DEFAULT '0',
				`time_end` int(10) NOT NULL DEFAULT '0'
				) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;";

				require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
				dbDelta( $sql );
			endif;

			$alter = get_option( 'mec_alter' );
			if ( !is_plugin_active( 'modern-events-calendar/mec.php' ) && $alter != '1' ) {
				// sync table with postt types
				$autoincer = file_get_contents( $demo_directory_path . 'autoincer.txt' );

				$sync = "ALTER TABLE `$table_name` ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `ID` (`id`), ADD UNIQUE KEY ` post_id` (`post_id`), ADD KEY `repeat` (`repeat`);";

				$syncid = "ALTER TABLE `$table_name` MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=$autoincer;";

				$syncstart = "ALTER TABLE `$table_name` ADD `days` TEXT NULL DEFAULT NULL, ADD `time_start` INT(10) NOT NULL DEFAULT '0', ADD `time_end` INT(10) NOT NULL DEFAULT '0';";

				$syncndays = "ALTER TABLE `$table_name` ADD `not_in_days` TEXT NOT NULL DEFAULT '' AFTER `days`;";

				$syncdays = "ALTER TABLE `$table_name` CHANGE `days` `days` TEXT NOT NULL DEFAULT '';";

				$wpdb->query( $sync );
				$wpdb->query( $syncid );
				$wpdb->query( $syncstart );
				$wpdb->query( $syncndays );
				$wpdb->query( $syncdays );
				
				update_option( 'mec_alter', 1 );

			}

			// get data table content
			$sql_file = file_get_contents( $demo_directory_path . 'mec.php' );
			$query = "INSERT INTO " . $table_name . $sql_file . " ON DUPLICATE KEY UPDATE id=id;" ;
			// run query
			$wpdb->query( $query );

		endif;

	} // end vision_wbc_extended function

	add_action( 'wbc_importer_before_content_import', 'vision_wbc_mec_options', 10, 2 );
	/**
	 *  Delete Defult mec posts.
	 */
	function vision_wbc_mec_options() {

		$post_type = array( '0' => 'mec_calendars', '1' => 'mec-events' );

		foreach ( $post_type as $key => $value ) {

			$args = array(
				'post_type' => $value
			);

			$query = new WP_Query( $args );

			if ( $query->have_posts() ) {
				// The 2nd Loop
				while ( $query->have_posts() ) {

					$query->the_post();
					wp_delete_post( $query->post->ID );

				}
				wp_reset_postdata();
			}
		}

	}

endif;